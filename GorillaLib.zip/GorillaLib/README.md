# GorillaLib

A port of **BoneLib 3.2.2** (the BONELAB modding library) to **Gorilla Tag**, as a BepInEx plugin.
It gives mod authors the same kind of toolbox BoneLib gives BONELAB modders, and gives players a
BONELAB-style popup menu (BoneMenu) that opens when you press a button.

## For players
Install with BepInEx, put `GorillaLib.dll` in `BepInEx/plugins/GorillaLib/`.

- **Open / close the menu:** `Y` on the left controller (default). On desktop: `F1`.
- **Point** with your right controller (the hand opposite the toggle button) and pull the **trigger**.
  `-` / `+` on a row change numbers, rows with `ON/OFF` toggle, rows with `>` open a page.
- **Thumbstick left/right** flips between screens of a long page. **`<`** goes back, **`X`** closes.
- Keyboard: arrows move, Enter presses, Backspace goes back.
- The menu opens in front of you, facing you. Size, distance, haptics and the button are in
  *GorillaLib Settings*, or in `BepInEx/config/com.gorillalib.gorillalib.cfg`.

## For mod authors
```csharp
[BepInDependency(GorillaLibPlugin.GUID)]
public class MyMod : BaseUnityPlugin
{
    void Start()
    {
        Page page = Page.Root.CreatePage("My Mod", Color.green);
        page.CreateBool("God Mode", Color.white, false, on => Debug.Log(on));
        page.CreateInt("Speed", Color.cyan, 5, 1, 0, 10, v => speed = v);
        page.CreateFloat("Slow Mo", Color.yellow, 1f, 0.1f, 0.1f, 1f, v => Time.timeScale = v);
        page.CreateEnum("Mode", Color.white, MyMode.A, m => mode = (MyMode)m);
        page.CreateFunction("Do Thing", Color.red, () => Menu.DisplayDialog("Sure?", "Do it?", null, DoIt, null));

        Notifier.Send(new Notification { Title = "My Mod", Message = "Loaded!", Type = NotificationType.Success });
    }
}
```
Namespaces: `GorillaLib`, `GorillaLib.BoneMenu`, `GorillaLib.Notifications`.

| BoneLib | GorillaLib |
|---|---|
| `BoneMenu` pages, elements, dialogs | same names (`Page`, `Menu`, `FunctionElement`, `BoolElement`, `IntElement`, `FloatElement`, `EnumElement`, `LabelElement`, `PageLinkElement`, `DialogData`) |
| `Notifier.Send`, `Notification` | same |
| `Hooking.OnLevelLoaded` etc. | `Hooking.OnSceneLoaded`, `OnPlayerReferencesFound`, `OnRoomJoined`, `OnRoomLeft`, `OnMenuOpened`, `OnMenuClosed`, `CreateHook` (Harmony) |
| `Player` | `Player.GetHead / GetLeftHand / GetRightHand / GetPosition` |
| `Audio`, `HelperMethods`, `InvokeActionSafe` | ported |
| Marrow-only parts (guns, NPCs, crates, barcodes, SpawnCrate, SetRpm, avatars) | not ported, Gorilla Tag has no equivalent |

## Building
Set `GORILLATAG_DIR` to your Gorilla Tag folder (the one with `BepInEx`), then `dotnet build -c Release`.
The DLL is copied to `BepInEx/plugins/GorillaLib` automatically.

## Credits & license
GorillaLib is a port of [BoneLib](https://github.com/yowchap/BoneLib) (Gnonme, Lvna, Adi, adamdev, Camobiwon,
Lakatrazz and the other contributors listed in its README) and is released under the same **GPL-3.0** license.
