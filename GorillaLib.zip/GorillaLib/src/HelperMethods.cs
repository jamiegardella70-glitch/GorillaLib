using System;
using System.IO;
using System.Reflection;
using System.Text.RegularExpressions;
using UnityEngine;

namespace GorillaLib
{
    /// <summary>Misc helpers for mod creators.</summary>
    public static class HelperMethods
    {
        /// <summary>Removes "(Clone)" and trailing " (1)" style suffixes from an object name.</summary>
        public static string GetCleanObjectName(string name)
        {
            if (string.IsNullOrEmpty(name)) return "";
            name = name.Replace("(Clone)", "");
            name = Regex.Replace(name, @"\s*\(\d+\)\s*$", "");
            return name.Trim();
        }

        /// <summary>True when running on the standalone Quest build.</summary>
        public static bool IsAndroid()
        {
            return Application.platform == RuntimePlatform.Android;
        }

        /// <summary>Loads an asset bundle that is embedded as a resource in a mod's assembly.</summary>
        public static AssetBundle LoadEmbeddedAssetBundle(Assembly assembly, string resourceName)
        {
            byte[] bytes = GetResourceBytes(assembly, resourceName);
            return bytes == null ? null : AssetBundle.LoadFromMemory(bytes);
        }

        /// <summary>Loads an asset and flags it so Unity won't unload it when scenes change.</summary>
        public static T LoadPersistentAsset<T>(this AssetBundle bundle, string name) where T : UnityEngine.Object
        {
            if (bundle == null) return null;
            T asset = bundle.LoadAsset<T>(name);
            if (asset != null) asset.hideFlags = HideFlags.DontUnloadUnusedAsset;
            return asset;
        }

        /// <summary>Reads an embedded resource into a byte array (null if it doesn't exist).</summary>
        public static byte[] GetResourceBytes(Assembly assembly, string resourceName)
        {
            using (Stream s = assembly.GetManifestResourceStream(resourceName))
            {
                if (s == null) return null;
                using (MemoryStream ms = new MemoryStream())
                {
                    s.CopyTo(ms);
                    return ms.ToArray();
                }
            }
        }

        /// <summary>Checks whether an assembly (by simple name, e.g. "Assembly-CSharp") is loaded.</summary>
        public static bool CheckIfAssemblyLoaded(string assemblyName)
        {
            foreach (Assembly a in AppDomain.CurrentDomain.GetAssemblies())
            {
                if (string.Equals(a.GetName().Name, assemblyName, StringComparison.OrdinalIgnoreCase))
                    return true;
            }
            return false;
        }
    }
}
