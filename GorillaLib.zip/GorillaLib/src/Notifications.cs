using System;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

namespace GorillaLib.Notifications
{
    public enum NotificationType
    {
        Information,
        Warning,
        Error,
        Success,
        CustomIcon
    }

    /// <summary>A piece of notification text with a colour. A plain string converts to one.</summary>
    public class NotificationText
    {
        public string Text;
        public Color Color = Color.white;
        public bool RichText;

        public NotificationText() { }
        public NotificationText(string text) { Text = text; }
        public NotificationText(string text, Color color, bool richText = false) { Text = text; Color = color; RichText = richText; }

        public static implicit operator NotificationText(string text) { return new NotificationText(text); }
    }

    public class Notification
    {
        public NotificationText Title = "";
        public NotificationText Message = "";
        public bool ShowTitleOnPopup = true;
        /// <summary>How long the popup stays up, in seconds.</summary>
        public float PopupLength = 2f;
        public NotificationType Type = NotificationType.Information;
        public Texture2D CustomIcon;
    }

    /// <summary>Sends small popups that float in front of the player's face.</summary>
    public static class Notifier
    {
        private static readonly Queue<Notification> Pending = new Queue<Notification>();

        public static void Send(Notification notification)
        {
            if (notification == null) return;
            string title = notification.Title != null ? notification.Title.Text : "";
            string msg = notification.Message != null ? notification.Message.Text : "";
            ModConsole.Msg("[Notification] " + title + (string.IsNullOrEmpty(msg) ? "" : ": " + msg));
            if (!Preferences.Notifications.Value) return;
            Pending.Enqueue(notification);
        }

        internal static bool TryDequeue(out Notification n)
        {
            if (Pending.Count > 0) { n = Pending.Dequeue(); return true; }
            n = null;
            return false;
        }
    }

    /// <summary>Head-locked popup that shows queued notifications one after another.</summary>
    internal class ToastView : MonoBehaviour
    {
        private const float W = 520f, H = 120f;

        private Canvas _canvas;
        private RectTransform _content;
        private float _timeLeft;
        private Transform _head;

        private void Awake()
        {
            _canvas = BoneMenu.UIKit.MakeCanvas("GorillaLibToast", null, new Vector2(W, H), 0.0007f);
            _canvas.transform.SetParent(transform, false);
            _content = BoneMenu.UIKit.MakeRect("Content", _canvas.transform, Vector2.zero, new Vector2(W, H));
            _canvas.gameObject.SetActive(false);
        }

        private void LateUpdate()
        {
            Transform head = Player.GetHead();
            if (head != _head)
            {
                _head = head;
                _canvas.transform.SetParent(head != null ? head : transform, false);
                _canvas.transform.localPosition = new Vector3(0f, -0.12f, 0.5f);
                _canvas.transform.localRotation = Quaternion.identity;
            }

            if (_canvas.gameObject.activeSelf)
            {
                _timeLeft -= Time.unscaledDeltaTime; // unscaled so slow motion doesn't stretch popups
                if (_timeLeft <= 0f) _canvas.gameObject.SetActive(false);
            }

            if (!_canvas.gameObject.activeSelf && _head != null)
            {
                Notification n;
                if (Notifier.TryDequeue(out n)) Show(n);
            }
        }

        private void Show(Notification n)
        {
            for (int i = _content.childCount - 1; i >= 0; i--)
            {
                GameObject child = _content.GetChild(i).gameObject;
                child.SetActive(false);
                Destroy(child);
            }

            Color accent;
            switch (n.Type)
            {
                case NotificationType.Warning: accent = new Color(1f, 0.85f, 0.2f); break;
                case NotificationType.Error: accent = new Color(1f, 0.3f, 0.3f); break;
                case NotificationType.Success: accent = new Color(0.35f, 1f, 0.45f); break;
                default: accent = new Color(0.35f, 0.8f, 1f); break;
            }

            BoneMenu.UIKit.Box(_content, Vector2.zero, new Vector2(W + 8f, H + 8f), accent);
            BoneMenu.UIKit.Box(_content, Vector2.zero, new Vector2(W, H), new Color(0.05f, 0.05f, 0.07f, 0.97f));

            float textLeft = -W / 2f + 20f;
            if (n.Type == NotificationType.CustomIcon && n.CustomIcon != null)
            {
                BoneMenu.UIKit.Picture(_content, new Vector2(-W / 2f + 70f, 0f), new Vector2(90f, 90f), n.CustomIcon);
                textLeft = -W / 2f + 130f;
            }
            else
            {
                BoneMenu.UIKit.Box(_content, new Vector2(-W / 2f + 10f, 0f), new Vector2(14f, H), accent);
            }

            float textW = W / 2f - textLeft - 20f;
            float cx = textLeft + textW / 2f;
            bool showTitle = n.ShowTitleOnPopup && n.Title != null && !string.IsNullOrEmpty(n.Title.Text);
            if (showTitle)
            {
                Text t = BoneMenu.UIKit.Label(_content, new Vector2(cx, 28f), new Vector2(textW, 44f), n.Title.Text, 32, accent, TextAnchor.MiddleLeft);
                t.supportRichText = n.Title.RichText;
            }
            if (n.Message != null)
            {
                Text m = BoneMenu.UIKit.Label(_content, new Vector2(cx, showTitle ? -22f : 0f),
                                              new Vector2(textW, showTitle ? 56f : 100f), n.Message.Text, 26,
                                              n.Message.Color, TextAnchor.MiddleLeft);
                m.supportRichText = n.Message.RichText;
            }

            _timeLeft = Mathf.Max(0.5f, n.PopupLength);
            _canvas.gameObject.SetActive(true);
        }
    }
}
