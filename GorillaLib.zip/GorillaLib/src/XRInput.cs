using UnityEngine;
using UnityEngine.XR;

namespace GorillaLib
{
    /// <summary>Thin wrapper over Unity's XR input devices.</summary>
    internal static class XRInput
    {
        private static InputDevice Device(bool left)
        {
            return InputDevices.GetDeviceAtXRNode(left ? XRNode.LeftHand : XRNode.RightHand);
        }

        public static bool GetButton(bool left, InputFeatureUsage<bool> usage)
        {
            InputDevice d = Device(left);
            bool v;
            return d.isValid && d.TryGetFeatureValue(usage, out v) && v;
        }

        /// <summary>World-space pose of a controller, computed from the XR tracking space.</summary>
        public static bool TryGetPose(bool left, out Vector3 pos, out Quaternion rot)
        {
            pos = Vector3.zero;
            rot = Quaternion.identity;

            InputDevice d = Device(left);
            if (!d.isValid) return false;

            Vector3 p = Vector3.zero;
            Quaternion r = Quaternion.identity;
            if (!d.TryGetFeatureValue(CommonUsages.devicePosition, out p)) return false;
            if (!d.TryGetFeatureValue(CommonUsages.deviceRotation, out r)) return false;

            Transform space = Player.GetTrackingSpace();
            if (space != null)
            {
                pos = space.TransformPoint(p);
                rot = space.rotation * r;
            }
            else
            {
                pos = p;
                rot = r;
            }
            return true;
        }

        public static Vector2 GetStick(bool left)
        {
            InputDevice d = Device(left);
            Vector2 v;
            return d.isValid && d.TryGetFeatureValue(CommonUsages.primary2DAxis, out v) ? v : Vector2.zero;
        }

        public static bool GetTrigger(bool left)
        {
            return GetButton(left, CommonUsages.triggerButton);
        }

        public static void Haptic(bool left, float amplitude, float duration)
        {
            if (!Preferences.Haptics.Value) return;
            InputDevice d = Device(left);
            HapticCapabilities caps;
            if (d.isValid && d.TryGetHapticCapabilities(out caps) && caps.supportsImpulse)
                d.SendHapticImpulse(0u, amplitude, duration);
        }

        public static InputFeatureUsage<bool> UsageFor(MenuButton b)
        {
            switch (b)
            {
                case MenuButton.LeftPrimary:
                case MenuButton.RightPrimary:
                    return CommonUsages.primaryButton;
                case MenuButton.LeftSecondary:
                case MenuButton.RightSecondary:
                    return CommonUsages.secondaryButton;
                default:
                    return CommonUsages.primary2DAxisClick;
            }
        }

        public static bool IsLeft(MenuButton b)
        {
            return b == MenuButton.LeftPrimary || b == MenuButton.LeftSecondary || b == MenuButton.LeftStickClick;
        }
    }
}
