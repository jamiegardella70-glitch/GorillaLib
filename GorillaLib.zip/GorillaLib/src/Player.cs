using System;
using System.Reflection;
using UnityEngine;

namespace GorillaLib
{
    /// <summary>
    /// Easy access to data about the local player (head, hands, position).
    /// Gorilla Tag's player class is found by reflection so GorillaLib doesn't break
    /// when the game renames it (GorillaLocomotion.Player became GorillaLocomotion.GTPlayer).
    /// </summary>
    public static class Player
    {
        private const BindingFlags AnyMember =
            BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.Instance | BindingFlags.Static | BindingFlags.FlattenHierarchy;

        private static readonly string[] PlayerTypeNames = { "GorillaLocomotion.GTPlayer", "GorillaLocomotion.Player" };

        private static Component _player;
        private static Transform _left;
        private static Transform _right;
        private static Camera _cam;

        /// <summary>True once the local player and the head camera exist.</summary>
        public static bool ReferencesFound
        {
            get { return Resolve() && GetHead() != null; }
        }

        /// <summary>The game's local player component (GTPlayer / Player), or null.</summary>
        public static Component GetPlayerComponent()
        {
            Resolve();
            return _player;
        }

        public static Transform GetHead()
        {
            if (_cam == null) _cam = Camera.main;
            return _cam != null ? _cam.transform : null;
        }

        /// <summary>The tracked left controller transform, or null if it couldn't be found.</summary>
        public static Transform GetLeftHand() { Resolve(); return _left; }

        /// <summary>The tracked right controller transform, or null if it couldn't be found.</summary>
        public static Transform GetRightHand() { Resolve(); return _right; }

        public static Vector3 GetPosition()
        {
            Transform head = GetHead();
            return head != null ? head.position : Vector3.zero;
        }

        /// <summary>World pose of a hand. Falls back to raw XR tracking when the game's transforms aren't found.</summary>
        public static bool TryGetHandPose(bool left, out Vector3 position, out Quaternion rotation)
        {
            Transform t = left ? GetLeftHand() : GetRightHand();
            if (t != null)
            {
                position = t.position;
                rotation = t.rotation;
                return true;
            }
            return XRInput.TryGetPose(left, out position, out rotation);
        }

        /// <summary>The parent of the head camera, which is the XR tracking space in Gorilla Tag.</summary>
        internal static Transform GetTrackingSpace()
        {
            Transform head = GetHead();
            return head != null ? head.parent : null;
        }

        internal static void Invalidate()
        {
            _player = null;
            _left = null;
            _right = null;
            _cam = null;
        }

        internal static bool Resolve()
        {
            if (_player != null) return true;

            try
            {
                Type type = null;
                foreach (string name in PlayerTypeNames)
                {
                    type = FindType(name);
                    if (type != null) break;
                }
                if (type == null) return false;

                object instance = GetStatic(type, "Instance", "instance", "_instance");
                Component comp = instance as Component;
                if (comp == null) return false;

                _player = comp;
                _left = GetTransformMember(comp, "leftControllerTransform", "leftHandFollower");
                _right = GetTransformMember(comp, "rightControllerTransform", "rightHandFollower");
                return true;
            }
            catch (Exception e)
            {
                ModConsole.Debug("Player.Resolve failed: " + e.Message);
                return false;
            }
        }

        internal static Type FindType(string fullName)
        {
            foreach (Assembly asm in AppDomain.CurrentDomain.GetAssemblies())
            {
                try
                {
                    Type t = asm.GetType(fullName, false);
                    if (t != null) return t;
                }
                catch (Exception) { }
            }
            return null;
        }

        internal static object GetStatic(Type type, params string[] names)
        {
            foreach (string n in names)
            {
                PropertyInfo p = type.GetProperty(n, AnyMember);
                if (p != null)
                {
                    object v = p.GetValue(null, null);
                    if (v != null) return v;
                }
                FieldInfo f = type.GetField(n, AnyMember);
                if (f != null)
                {
                    object v = f.GetValue(null);
                    if (v != null) return v;
                }
            }
            return null;
        }

        private static Transform GetTransformMember(object o, params string[] names)
        {
            Type type = o.GetType();
            foreach (string n in names)
            {
                object v = null;
                FieldInfo f = type.GetField(n, AnyMember);
                if (f != null) v = f.GetValue(o);
                else
                {
                    PropertyInfo p = type.GetProperty(n, AnyMember);
                    if (p != null) v = p.GetValue(o, null);
                }
                Transform t = v as Transform;
                if (t != null) return t;
            }
            return null;
        }
    }
}
