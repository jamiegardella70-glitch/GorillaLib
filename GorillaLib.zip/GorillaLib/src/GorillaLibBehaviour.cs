using UnityEngine;
using GorillaLib.BoneMenu;
using GorillaLib.Notifications;

namespace GorillaLib
{
    /// <summary>Per-frame driver: ticks the events and opens the menu when the keybind is pressed.</summary>
    internal class GorillaLibBehaviour : MonoBehaviour
    {
        private bool _prevToggle;

        private void Awake()
        {
            Hooking.Init();
            gameObject.AddComponent<MenuView>();
            gameObject.AddComponent<ToastView>();
            BuiltInPages.Build();
        }

        private void Update()
        {
            Hooking.Tick();

            MenuButton btn = Preferences.ToggleButton.Value;
            bool down = XRInput.GetButton(XRInput.IsLeft(btn), XRInput.UsageFor(btn));
            if (down && !_prevToggle)
            {
                XRInput.Haptic(XRInput.IsLeft(btn), 0.3f, 0.05f);
                Menu.Toggle();
            }
            _prevToggle = down;

            if (Preferences.EnableKeyboard.Value)
            {
                try { if (Input.GetKeyDown(Preferences.ToggleKey.Value)) Menu.Toggle(); }
                catch (System.InvalidOperationException) { }
            }
        }
    }

    /// <summary>The pages GorillaLib adds to the menu itself.</summary>
    internal static class BuiltInPages
    {
        public static void Build()
        {
            Page root = Page.Root;
            Color cyan = new Color(0.35f, 0.8f, 1f);

            root.CreateLabel("Mods add their pages below", new Color(0.65f, 0.65f, 0.7f));

            Page settings = root.CreatePage("GorillaLib Settings", new Color(1f, 0.8f, 0.3f));
            settings.CreateBool("Haptics", cyan, Preferences.Haptics.Value, v => Preferences.Haptics.Value = v)
                .Tooltip = "Vibrate the controller when pressing menu buttons.";
            settings.CreateBool("Notifications", cyan, Preferences.Notifications.Value, v => Preferences.Notifications.Value = v)
                .Tooltip = "Show popups from mods.";
            settings.CreateInt("Menu Size %", cyan, Preferences.MenuSizePercent.Value, 10, 50, 200,
                v => { Preferences.MenuSizePercent.Value = v; Menu.JustOpened = true; })
                .Tooltip = "Resizes the menu right away.";
            settings.CreateInt("Menu Distance cm", cyan, Preferences.MenuDistanceCm.Value, 5, 25, 120,
                v => { Preferences.MenuDistanceCm.Value = v; Menu.JustOpened = true; })
                .Tooltip = "How far in front of your face the menu opens.";
            settings.CreateEnum("Menu Button", cyan, Preferences.ToggleButton.Value,
                v => Preferences.ToggleButton.Value = (MenuButton)v)
                .Tooltip = "Controller button that opens and closes the menu.";
            settings.CreateFunction("Test Notification", new Color(0.35f, 1f, 0.45f), () =>
                Notifier.Send(new Notification
                {
                    Title = "GorillaLib",
                    Message = "Notifications are working.",
                    Type = NotificationType.Success,
                    PopupLength = 2f
                }));

            Page about = root.CreatePage("About", new Color(0.8f, 0.5f, 1f));
            about.CreateLabel("GorillaLib " + GorillaLibPlugin.Version, Color.white);
            about.CreateLabel("Port of BoneLib 3.2.2", new Color(0.65f, 0.65f, 0.7f));
            about.CreateLabel("BoneLib by the BONELAB modding community", new Color(0.65f, 0.65f, 0.7f));

            root.CreateFunction("Close Menu", new Color(1f, 0.4f, 0.4f), Menu.Close);
        }
    }
}
