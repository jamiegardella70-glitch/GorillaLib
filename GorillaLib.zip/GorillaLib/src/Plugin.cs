using BepInEx;
using BepInEx.Configuration;
using BepInEx.Logging;
using UnityEngine;

namespace GorillaLib
{
    /// <summary>
    /// GorillaLib: a modding library for Gorilla Tag, ported in spirit from BoneLib (BONELAB).
    /// Other mods can depend on it with [BepInDependency(GorillaLibPlugin.GUID)].
    /// </summary>
    [BepInPlugin(GUID, Name, Version)]
    public class GorillaLibPlugin : BaseUnityPlugin
    {
        public const string GUID = "com.gorillalib.gorillalib";
        public const string Name = "GorillaLib";
        public const string Version = "1.0.0";

        private void Awake()
        {
            ModConsole.Init(Logger);
            Preferences.Bind(Config);

            GameObject go = new GameObject("GorillaLib");
            go.hideFlags = HideFlags.HideAndDontSave;
            DontDestroyOnLoad(go);
            go.AddComponent<GorillaLibBehaviour>();

            ModConsole.Msg("GorillaLib " + Version + " loaded.");
        }
    }

    /// <summary>Console logging that goes to the BepInEx log.</summary>
    public static class ModConsole
    {
        private static ManualLogSource _log;

        internal static void Init(ManualLogSource log) { _log = log; }

        public static void Msg(object message) { if (_log != null) _log.LogInfo(message); }
        public static void Warning(object message) { if (_log != null) _log.LogWarning(message); }
        public static void Error(object message) { if (_log != null) _log.LogError(message); }
        public static void Debug(object message) { if (_log != null) _log.LogDebug(message); }
    }

    /// <summary>Which controller button opens/closes the menu.</summary>
    public enum MenuButton
    {
        LeftSecondary,   // Y (Quest/Touch) / B (Index)
        LeftPrimary,     // X / A
        RightSecondary,  // B / B
        RightPrimary,    // A / A
        LeftStickClick,
        RightStickClick
    }

    /// <summary>User preferences, stored in BepInEx/config/com.gorillalib.gorillalib.cfg.</summary>
    internal static class Preferences
    {
        public static ConfigEntry<MenuButton> ToggleButton;
        public static ConfigEntry<KeyCode> ToggleKey;
        public static ConfigEntry<bool> EnableKeyboard;
        public static ConfigEntry<bool> Haptics;
        public static ConfigEntry<bool> Notifications;
        public static ConfigEntry<int> MenuSizePercent;
        public static ConfigEntry<int> MenuDistanceCm;

        public static void Bind(ConfigFile c)
        {
            ToggleButton = c.Bind("Menu", "ToggleButton", MenuButton.LeftSecondary,
                "VR controller button that opens/closes the GorillaLib menu.");
            ToggleKey = c.Bind("Menu", "ToggleKey", KeyCode.F1,
                "Keyboard key that opens/closes the menu (for desktop testing).");
            EnableKeyboard = c.Bind("Menu", "EnableKeyboard", true,
                "Allow keyboard control of the menu (arrows, Enter, Backspace).");
            Haptics = c.Bind("Menu", "Haptics", true, "Vibrate the controller when pressing menu buttons.");
            Notifications = c.Bind("Menu", "Notifications", true, "Show notification popups.");
            MenuSizePercent = c.Bind("Menu", "SizePercent", 100,
                new ConfigDescription("Menu size in percent.", new AcceptableValueRange<int>(50, 200)));
            MenuDistanceCm = c.Bind("Menu", "DistanceCm", 55,
                new ConfigDescription("How far in front of your face the menu appears, in centimetres.",
                    new AcceptableValueRange<int>(25, 120)));
        }
    }
}
