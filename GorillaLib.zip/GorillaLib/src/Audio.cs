using UnityEngine;

namespace GorillaLib
{
    /// <summary>Simple audio helpers.</summary>
    public static class Audio
    {
        private static AudioSource _source2D;

        private static AudioSource Get2D()
        {
            if (_source2D == null)
            {
                GameObject go = new GameObject("GorillaLib.Audio2D");
                go.hideFlags = HideFlags.HideAndDontSave;
                UnityEngine.Object.DontDestroyOnLoad(go);
                _source2D = go.AddComponent<AudioSource>();
                _source2D.spatialBlend = 0f;
                _source2D.playOnAwake = false;
            }
            return _source2D;
        }

        /// <summary>Plays a non-positional sound.</summary>
        public static void Play2DOneShot(AudioClip clip, float volume = 1f, float pitch = 1f)
        {
            if (clip == null) return;
            AudioSource src = Get2D();
            src.pitch = pitch;
            src.PlayOneShot(clip, volume);
        }

        /// <summary>Plays a random clip from the array, non-positional.</summary>
        public static void Play2DOneShot(AudioClip[] clips, float volume = 1f, float pitch = 1f)
        {
            if (clips == null || clips.Length == 0) return;
            Play2DOneShot(clips[Random.Range(0, clips.Length)], volume, pitch);
        }

        /// <summary>Plays a sound at a world position (spatialBlend 1 = fully 3D).</summary>
        public static void PlayAtPoint(AudioClip clip, Vector3 position, float volume = 1f, float pitch = 1f, float spatialBlend = 1f)
        {
            if (clip == null) return;
            GameObject go = new GameObject("GorillaLib.OneShot");
            go.transform.position = position;
            AudioSource src = go.AddComponent<AudioSource>();
            src.clip = clip;
            src.volume = volume;
            src.pitch = pitch;
            src.spatialBlend = spatialBlend;
            src.Play();
            UnityEngine.Object.Destroy(go, clip.length / Mathf.Max(0.01f, Mathf.Abs(pitch)) + 0.1f);
        }

        /// <summary>Plays a random clip from the array at a world position.</summary>
        public static void PlayAtPoint(AudioClip[] clips, Vector3 position, float volume = 1f, float pitch = 1f, float spatialBlend = 1f)
        {
            if (clips == null || clips.Length == 0) return;
            PlayAtPoint(clips[Random.Range(0, clips.Length)], position, volume, pitch, spatialBlend);
        }

        /// <summary>Sets the global listener volume, 0 to 100.</summary>
        public static void SetMasterVolume(int volume)
        {
            AudioListener.volume = Mathf.Clamp01(volume / 100f);
        }
    }
}
