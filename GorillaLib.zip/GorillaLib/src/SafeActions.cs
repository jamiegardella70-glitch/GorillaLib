using System;

namespace GorillaLib
{
    /// <summary>
    /// Extension methods that invoke delegates with null checks and error handling,
    /// so one broken callback can't take down the caller.
    /// </summary>
    public static class SafeActions
    {
        public static void InvokeActionSafe(this Action action)
        {
            if (action == null) return;
            try { action(); }
            catch (Exception e) { ModConsole.Error("Exception in action: " + e); }
        }

        public static void InvokeActionSafe<T>(this Action<T> action, T arg)
        {
            if (action == null) return;
            try { action(arg); }
            catch (Exception e) { ModConsole.Error("Exception in action: " + e); }
        }

        public static void InvokeActionSafe<T1, T2>(this Action<T1, T2> action, T1 a, T2 b)
        {
            if (action == null) return;
            try { action(a, b); }
            catch (Exception e) { ModConsole.Error("Exception in action: " + e); }
        }

        public static void InvokeActionSafe<T1, T2, T3>(this Action<T1, T2, T3> action, T1 a, T2 b, T3 c)
        {
            if (action == null) return;
            try { action(a, b, c); }
            catch (Exception e) { ModConsole.Error("Exception in action: " + e); }
        }

        /// <summary>Invokes every subscriber of an event separately, so one throwing doesn't stop the rest.</summary>
        internal static void RaiseSafe(this Action action)
        {
            if (action == null) return;
            foreach (Delegate d in action.GetInvocationList())
            {
                try { ((Action)d)(); }
                catch (Exception e) { ModConsole.Error("Exception in event handler: " + e); }
            }
        }

        internal static void RaiseSafe<T>(this Action<T> action, T arg)
        {
            if (action == null) return;
            foreach (Delegate d in action.GetInvocationList())
            {
                try { ((Action<T>)d)(arg); }
                catch (Exception e) { ModConsole.Error("Exception in event handler: " + e); }
            }
        }
    }
}
