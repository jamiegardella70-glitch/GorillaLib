using System;
using UnityEngine;

namespace GorillaLib.BoneMenu
{
    /// <summary>Base class for everything that can sit in a menu page.</summary>
    public abstract class Element
    {
        /// <summary>Text shown on the element.</summary>
        public string Name { get; set; }

        /// <summary>Accent colour of the element.</summary>
        public Color Color { get; set; }

        /// <summary>Optional text shown at the bottom of the menu while the element is hovered.</summary>
        public string Tooltip { get; set; }

        /// <summary>The page this element lives on (null if it hasn't been added).</summary>
        public Page Parent { get; internal set; }

        protected Element(string name, Color color)
        {
            Name = name;
            Color = color;
        }

        /// <summary>Text drawn on the right side of the row.</summary>
        internal virtual string ValueText { get { return ""; } }

        internal virtual Color ValueColor { get { return Color.white; } }

        /// <summary>True when the row shows - and + buttons at its ends.</summary>
        internal virtual bool Stepper { get { return false; } }

        /// <summary>False for things like labels that can't be pressed.</summary>
        internal virtual bool Interactable { get { return true; } }

        /// <summary>zone: -1 = left button, 0 = middle of the row, +1 = right button.</summary>
        internal abstract void Activate(int zone);

        /// <summary>Redraws the menu after this element changed.</summary>
        protected void Changed() { Menu.MarkDirty(); }
    }

    /// <summary>A button that runs an action.</summary>
    public class FunctionElement : Element
    {
        public Action Callback;

        public FunctionElement(string name, Color color, Action callback) : base(name, color)
        {
            Callback = callback;
        }

        internal override void Activate(int zone) { Callback.InvokeActionSafe(); }
    }

    /// <summary>An ON/OFF toggle.</summary>
    public class BoolElement : Element
    {
        private bool _value;

        public Action<bool> Callback;

        public BoolElement(string name, Color color, bool startValue, Action<bool> callback) : base(name, color)
        {
            _value = startValue;
            Callback = callback;
        }

        public bool Value
        {
            get { return _value; }
            set { Set(value, true); }
        }

        /// <summary>Changes the value, optionally without running the callback.</summary>
        public void Set(bool value, bool invoke)
        {
            if (_value == value) return;
            _value = value;
            if (invoke) Callback.InvokeActionSafe(value);
            Changed();
        }

        internal override string ValueText { get { return _value ? "ON" : "OFF"; } }
        internal override Color ValueColor { get { return _value ? new Color(0.35f, 1f, 0.45f) : new Color(1f, 0.4f, 0.4f); } }
        internal override void Activate(int zone) { Value = !_value; }
    }

    /// <summary>A whole-number value with - and + buttons.</summary>
    public class IntElement : Element
    {
        private int _value;

        public int Increment, MinValue, MaxValue;
        public Action<int> Callback;

        public IntElement(string name, Color color, int startValue, int increment, int minValue, int maxValue, Action<int> callback)
            : base(name, color)
        {
            Increment = increment;
            MinValue = minValue;
            MaxValue = maxValue;
            _value = Mathf.Clamp(startValue, minValue, maxValue);
            Callback = callback;
        }

        public int Value
        {
            get { return _value; }
            set
            {
                int v = Mathf.Clamp(value, MinValue, MaxValue);
                if (v == _value) return;
                _value = v;
                Callback.InvokeActionSafe(v);
                Changed();
            }
        }

        internal override string ValueText { get { return _value.ToString(); } }
        internal override bool Stepper { get { return true; } }
        internal override void Activate(int zone) { if (zone != 0) Value = _value + zone * Increment; }
    }

    /// <summary>A decimal value with - and + buttons.</summary>
    public class FloatElement : Element
    {
        private float _value;

        public float Increment, MinValue, MaxValue;
        public Action<float> Callback;

        public FloatElement(string name, Color color, float startValue, float increment, float minValue, float maxValue, Action<float> callback)
            : base(name, color)
        {
            Increment = increment;
            MinValue = minValue;
            MaxValue = maxValue;
            _value = Mathf.Clamp(startValue, minValue, maxValue);
            Callback = callback;
        }

        public float Value
        {
            get { return _value; }
            set
            {
                float v = Mathf.Clamp(value, MinValue, MaxValue);
                if (Mathf.Approximately(v, _value)) return;
                _value = v;
                Callback.InvokeActionSafe(v);
                Changed();
            }
        }

        internal override string ValueText { get { return _value.ToString("0.##"); } }
        internal override bool Stepper { get { return true; } }

        internal override void Activate(int zone)
        {
            if (zone == 0) return;
            // Round so repeated 0.1 steps don't drift (0.30000001 etc).
            float step = Increment <= 0f ? 0.1f : Increment;
            Value = Mathf.Round((_value + zone * step) / step * 1000f) / 1000f * step;
        }
    }

    /// <summary>Cycles through the values of an enum when pressed.</summary>
    public class EnumElement : Element
    {
        private readonly Array _values;
        private int _index;

        public Action<Enum> Callback;

        public EnumElement(string name, Color color, Enum startValue, Action<Enum> callback) : base(name, color)
        {
            _values = Enum.GetValues(startValue.GetType());
            _index = Array.IndexOf(_values, startValue);
            if (_index < 0) _index = 0;
            Callback = callback;
        }

        public Enum Value
        {
            get { return (Enum)_values.GetValue(_index); }
            set
            {
                int i = Array.IndexOf(_values, value);
                if (i < 0 || i == _index) return;
                _index = i;
                Callback.InvokeActionSafe(Value);
                Changed();
            }
        }

        internal override string ValueText { get { return Value.ToString(); } }
        internal override bool Stepper { get { return true; } }

        internal override void Activate(int zone)
        {
            int dir = zone == 0 ? 1 : zone;
            _index = (_index + dir + _values.Length) % _values.Length;
            Callback.InvokeActionSafe(Value);
            Changed();
        }
    }

    /// <summary>Plain text row, not pressable.</summary>
    public class LabelElement : Element
    {
        public LabelElement(string name, Color color) : base(name, color) { }

        internal override bool Interactable { get { return false; } }
        internal override void Activate(int zone) { }
    }

    /// <summary>Opens another page.</summary>
    public class PageLinkElement : Element
    {
        public Page Target { get; private set; }

        public PageLinkElement(Page target) : base(target.Name, target.Color)
        {
            Target = target;
        }

        internal override string ValueText { get { return ">"; } }
        internal override void Activate(int zone) { Menu.OpenPage(Target); }
    }
}
