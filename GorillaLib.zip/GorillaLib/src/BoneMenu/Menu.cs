using System;
using UnityEngine;

namespace GorillaLib.BoneMenu
{
    /// <summary>Contents of a yes/no popup shown inside the menu.</summary>
    public class DialogData
    {
        public string Title;
        public string Message;
        /// <summary>Runs when the green button is pressed.</summary>
        public Action Primary;
        /// <summary>Runs when the red button is pressed.</summary>
        public Action Secondary;
        public Texture2D Icon;
        public string PrimaryText = "Yes";
        public string SecondaryText = "No";
        public Color PrimaryColor = new Color(0.35f, 1f, 0.45f);
        public Color SecondaryColor = new Color(1f, 0.4f, 0.4f);
    }

    /// <summary>Controls the popup menu: opening, closing and moving between pages.</summary>
    public static class Menu
    {
        private static Page _current;

        /// <summary>True while the menu is on screen.</summary>
        public static bool IsOpen { get; private set; }

        /// <summary>The page being shown. Defaults to <see cref="Page.Root"/>.</summary>
        public static Page CurrentPage
        {
            get { return _current ?? Page.Root; }
        }

        internal static DialogData ActiveDialog { get; set; }
        internal static bool Dirty { get; set; }
        internal static bool JustOpened { get; set; }

        public static void Open()
        {
            if (IsOpen) return;
            IsOpen = true;
            JustOpened = true;
            Dirty = true;
            Hooking.RaiseMenuOpened();
        }

        public static void Close()
        {
            if (!IsOpen) return;
            IsOpen = false;
            ActiveDialog = null;
            Hooking.RaiseMenuClosed();
        }

        public static void Toggle()
        {
            if (IsOpen) Close(); else Open();
        }

        /// <summary>Opens the menu on <paramref name="page"/>.</summary>
        public static void OpenPage(Page page)
        {
            if (page == null) return;
            _current = page;
            ActiveDialog = null;
            Dirty = true;
        }

        /// <summary>Goes up one page, or closes the menu when already on the root.</summary>
        public static void GoBack()
        {
            if (ActiveDialog != null) { ActiveDialog = null; Dirty = true; return; }
            Page p = CurrentPage;
            if (p.Parent != null) OpenPage(p.Parent);
            else Close();
        }

        /// <summary>Shows the previous screen of elements on the current page.</summary>
        public static void PreviousPage() { CurrentPage.PreviousPage(); }

        /// <summary>Shows the next screen of elements on the current page.</summary>
        public static void NextPage() { CurrentPage.NextPage(); }

        /// <summary>Removes <paramref name="page"/> from its parent. If it's showing, goes up a level.</summary>
        public static void DestroyPage(Page page)
        {
            if (page == null || page == Page.Root) return;
            if (_current == page) OpenPage(page.Parent ?? Page.Root);
            if (page.Parent != null) page.Parent.RemovePage(page);
        }

        public static void DisplayDialog(string title, string message, Texture2D icon, Action confirmAction, Action denyAction)
        {
            DisplayDialog(new DialogData
            {
                Title = title,
                Message = message,
                Icon = icon,
                Primary = confirmAction,
                Secondary = denyAction
            });
        }

        /// <summary>Shows a popup. The menu opens if it was closed.</summary>
        public static void DisplayDialog(DialogData data)
        {
            if (data == null) return;
            ActiveDialog = data;
            Dirty = true;
            Open();
        }

        internal static void MarkDirty() { Dirty = true; }
    }
}
