using UnityEngine;
using UnityEngine.UI;

namespace GorillaLib.BoneMenu
{
    /// <summary>Small helpers for building the world-space UI.</summary>
    internal static class UIKit
    {
        private static Font _font;
        private static Material _mat;

        public static Font Font
        {
            get
            {
                if (_font != null) return _font;
                // Unity 2022 renamed the built-in font; try both.
                try { _font = Resources.GetBuiltinResource<Font>("LegacyRuntime.ttf"); } catch { }
                if (_font == null)
                {
                    try { _font = Resources.GetBuiltinResource<Font>("Arial.ttf"); } catch { }
                }
                if (_font == null) _font = Font.CreateDynamicFontFromOSFont("Arial", 32);
                return _font;
            }
        }

        /// <summary>UI material that always draws on top of the world, so walls can't hide the menu.</summary>
        public static Material Material
        {
            get
            {
                if (_mat != null) return _mat;
                Shader sh = Shader.Find("UI/Default");
                if (sh == null) return null;
                _mat = new Material(sh);
                _mat.SetInt("unity_GUIZTestMode", 8); // CompareFunction.Always
                _mat.renderQueue = 4000;
                return _mat;
            }
        }

        public static Canvas MakeCanvas(string name, Transform parent, Vector2 size, float scale)
        {
            GameObject go = new GameObject(name);
            if (parent != null) go.transform.SetParent(parent, false);
            Canvas c = go.AddComponent<Canvas>();
            c.renderMode = RenderMode.WorldSpace;
            RectTransform rt = c.GetComponent<RectTransform>();
            rt.sizeDelta = size;
            rt.localScale = Vector3.one * scale;
            return c;
        }

        public static RectTransform MakeRect(string name, Transform parent, Vector2 center, Vector2 size)
        {
            GameObject go = new GameObject(name, typeof(RectTransform));
            go.transform.SetParent(parent, false);
            RectTransform rt = (RectTransform)go.transform;
            rt.anchorMin = rt.anchorMax = rt.pivot = new Vector2(0.5f, 0.5f);
            rt.anchoredPosition = center;
            rt.sizeDelta = size;
            return rt;
        }

        public static Image Box(Transform parent, Vector2 center, Vector2 size, Color color)
        {
            RectTransform rt = MakeRect("Box", parent, center, size);
            Image img = rt.gameObject.AddComponent<Image>();
            img.color = color;
            img.raycastTarget = false;
            if (Material != null) img.material = Material;
            return img;
        }

        public static RawImage Picture(Transform parent, Vector2 center, Vector2 size, Texture tex)
        {
            RectTransform rt = MakeRect("Icon", parent, center, size);
            RawImage img = rt.gameObject.AddComponent<RawImage>();
            img.texture = tex;
            img.raycastTarget = false;
            if (Material != null) img.material = Material;
            return img;
        }

        public static Text Label(Transform parent, Vector2 center, Vector2 size, string text, int fontSize,
                                 Color color, TextAnchor anchor)
        {
            RectTransform rt = MakeRect("Text", parent, center, size);
            Text t = rt.gameObject.AddComponent<Text>();
            t.font = Font;
            t.fontSize = fontSize;
            t.color = color;
            t.alignment = anchor;
            t.horizontalOverflow = HorizontalWrapMode.Wrap;
            t.verticalOverflow = VerticalWrapMode.Truncate;
            t.supportRichText = true;
            t.raycastTarget = false;
            t.text = text ?? "";
            if (Material != null) t.material = Material;
            return t;
        }

        public static Color Scale(Color c, float f)
        {
            return new Color(Mathf.Clamp01(c.r * f), Mathf.Clamp01(c.g * f), Mathf.Clamp01(c.b * f), c.a);
        }

        public static Color WithAlpha(Color c, float a)
        {
            return new Color(c.r, c.g, c.b, a);
        }
    }
}
