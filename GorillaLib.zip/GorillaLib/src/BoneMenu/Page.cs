using System;
using System.Collections.Generic;
using UnityEngine;

namespace GorillaLib.BoneMenu
{
    /// <summary>
    /// A page of the menu. Mods get their own page with
    /// <c>Page.Root.CreatePage("My Mod", Color.cyan)</c> and fill it with elements.
    /// </summary>
    public class Page
    {
        /// <summary>The top level page every mod hangs off.</summary>
        public static Page Root { get; private set; }

        /// <summary>The most rows the menu can show at once.</summary>
        public const int HardMaxElements = 6;

        private readonly List<Element> _elements = new List<Element>();
        private readonly List<Page> _children = new List<Page>();
        private int _maxElements;

        static Page()
        {
            Root = new Page("GorillaLib", new Color(0.35f, 0.8f, 1f), HardMaxElements, null);
        }

        internal Page(string name, Color color, int maxElements, Page parent)
        {
            Name = name;
            Color = color;
            MaxElements = maxElements;
            Parent = parent;
        }

        public string Name { get; set; }
        public Color Color { get; set; }
        public Page Parent { get; private set; }

        /// <summary>How many elements fit on one screen of this page (1 to 6).</summary>
        public int MaxElements
        {
            get { return _maxElements; }
            set { _maxElements = Mathf.Clamp(value, 1, HardMaxElements); }
        }

        public IList<Element> Elements { get { return _elements.AsReadOnly(); } }
        public IList<Page> Children { get { return _children.AsReadOnly(); } }

        /// <summary>Which screen of elements is showing (0 based).</summary>
        public int PageIndex { get; private set; }

        public int PageCount
        {
            get { return Mathf.Max(1, Mathf.CeilToInt(_elements.Count / (float)_maxElements)); }
        }

        // ---- elements ------------------------------------------------------------------

        public void Add(Element element)
        {
            if (element == null) return;
            element.Parent = this;
            _elements.Add(element);
            Menu.MarkDirty();
        }

        public void Remove(Element element)
        {
            if (element != null && _elements.Remove(element)) { element.Parent = null; ClampIndex(); Menu.MarkDirty(); }
        }

        public void Remove(Element[] elements)
        {
            if (elements == null) return;
            foreach (Element e in elements) Remove(e);
        }

        public void RemoveAll()
        {
            foreach (Element e in _elements) e.Parent = null;
            _elements.Clear();
            _children.Clear();
            PageIndex = 0;
            Menu.MarkDirty();
        }

        // ---- child pages ---------------------------------------------------------------

        /// <summary>Makes a sub page. With createLink a button for it is added to this page.</summary>
        public Page CreatePage(string name, Color color, int maxElements = HardMaxElements, bool createLink = true)
        {
            Page child = new Page(name, color, maxElements, this);
            _children.Add(child);
            if (createLink) Add(new PageLinkElement(child));
            return child;
        }

        public Page CreatePage() { return CreatePage("Page", Color.white); }

        /// <summary>Adds a button on this page that opens <paramref name="page"/>.</summary>
        public PageLinkElement CreatePageLink(Page page)
        {
            PageLinkElement link = new PageLinkElement(page);
            Add(link);
            return link;
        }

        public Page GetChildPage(string name)
        {
            foreach (Page p in _children) if (p.Name == name) return p;
            return null;
        }

        public bool TryGetChildPage(string name, out Page page)
        {
            page = GetChildPage(name);
            return page != null;
        }

        public void RemovePage(Page page)
        {
            if (page == null) return;
            _children.Remove(page);
            RemovePageLinks(page);
            Menu.MarkDirty();
        }

        public void RemovePages(Page[] pages)
        {
            if (pages == null) return;
            foreach (Page p in pages) RemovePage(p);
        }

        /// <summary>Removes the buttons on this page that point at <paramref name="page"/>.</summary>
        public void RemovePageLinks(Page page)
        {
            for (int i = _elements.Count - 1; i >= 0; i--)
            {
                PageLinkElement link = _elements[i] as PageLinkElement;
                if (link != null && link.Target == page) { _elements[i].Parent = null; _elements.RemoveAt(i); }
            }
            ClampIndex();
            Menu.MarkDirty();
        }

        // ---- screens of elements ---------------------------------------------------------

        public void NextPage() { SetIndex(PageIndex + 1); }
        public void PreviousPage() { SetIndex(PageIndex - 1); }

        private void SetIndex(int i)
        {
            int clamped = Mathf.Clamp(i, 0, PageCount - 1);
            if (clamped == PageIndex) return;
            PageIndex = clamped;
            Menu.MarkDirty();
        }

        private void ClampIndex() { PageIndex = Mathf.Clamp(PageIndex, 0, PageCount - 1); }

        /// <summary>The elements visible on the current screen.</summary>
        internal List<Element> VisibleElements()
        {
            ClampIndex();
            int start = PageIndex * _maxElements;
            int count = Mathf.Min(_maxElements, _elements.Count - start);
            return count > 0 ? _elements.GetRange(start, count) : new List<Element>();
        }

        // ---- shortcuts to create elements -----------------------------------------------

        public FunctionElement CreateFunction(string name, Color color, Action callback)
        {
            FunctionElement e = new FunctionElement(name, color, callback);
            Add(e);
            return e;
        }

        public BoolElement CreateBool(string name, Color color, bool startValue, Action<bool> callback)
        {
            BoolElement e = new BoolElement(name, color, startValue, callback);
            Add(e);
            return e;
        }

        public IntElement CreateInt(string name, Color color, int startValue, int increment, int minValue, int maxValue, Action<int> callback)
        {
            IntElement e = new IntElement(name, color, startValue, increment, minValue, maxValue, callback);
            Add(e);
            return e;
        }

        public FloatElement CreateFloat(string name, Color color, float startValue, float increment, float minValue, float maxValue, Action<float> callback)
        {
            FloatElement e = new FloatElement(name, color, startValue, increment, minValue, maxValue, callback);
            Add(e);
            return e;
        }

        public EnumElement CreateEnum(string name, Color color, Enum startValue, Action<Enum> callback)
        {
            EnumElement e = new EnumElement(name, color, startValue, callback);
            Add(e);
            return e;
        }

        public LabelElement CreateLabel(string name, Color color)
        {
            LabelElement e = new LabelElement(name, color);
            Add(e);
            return e;
        }
    }
}
