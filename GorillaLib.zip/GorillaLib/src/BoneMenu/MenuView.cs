using System;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.XR;

namespace GorillaLib.BoneMenu
{
    /// <summary>
    /// Draws the popup menu as a world-space canvas in front of the player and handles pointing
    /// (controller laser + trigger, or mouse) and keyboard input.
    /// </summary>
    internal class MenuView : MonoBehaviour
    {
        // Layout in canvas pixels. The canvas origin is its centre, +y is up.
        private const float W = 560f, H = 740f;
        private const float HeaderH = 90f, FooterH = 110f;
        private const float RowH = 80f, Gap = 10f, Pad = 20f;
        private const float StepW = 90f;
        private const float BaseScale = 0.0008f; // metres per pixel at 100% size

        private class Hit
        {
            public Vector2 Center, Size;
            public Action<int> Click;
            public Image Bg;
            public Color BaseColor;
            public string Tooltip;
            public bool IsRow;
            public bool Stepper;
        }

        private Canvas _canvas;
        private RectTransform _content;
        private LineRenderer _laser;
        private Image _cursor;
        private readonly List<Hit> _hits = new List<Hit>();
        private Hit _hovered;
        private int _focus = -1;
        private bool _kbMode;
        private bool _shown;
        private bool _prevTrigger;
        private bool _stickReady = true;
        private Text _tooltipText;
        private bool _rebuilt;

        private void Awake()
        {
            _canvas = UIKit.MakeCanvas("GorillaLibMenu", null, new Vector2(W, H), BaseScale);
            _canvas.transform.SetParent(transform, false);
            _content = UIKit.MakeRect("Content", _canvas.transform, Vector2.zero, new Vector2(W, H));
            _cursor = UIKit.Box(_canvas.transform, Vector2.zero, new Vector2(18f, 18f), Color.white);
            _cursor.gameObject.SetActive(false);

            GameObject lg = new GameObject("GorillaLibLaser");
            lg.transform.SetParent(transform, false);
            _laser = lg.AddComponent<LineRenderer>();
            _laser.positionCount = 2;
            _laser.startWidth = _laser.endWidth = 0.004f;
            _laser.useWorldSpace = true;
            Shader sh = Shader.Find("Sprites/Default");
            if (sh != null) _laser.material = new Material(sh);
            _laser.startColor = _laser.endColor = new Color(0.35f, 0.8f, 1f, 0.9f);
            _laser.enabled = false;

            _canvas.gameObject.SetActive(false);
        }

        private void Update()
        {
            if (Menu.IsOpen != _shown)
            {
                _shown = Menu.IsOpen;
                _canvas.gameObject.SetActive(_shown);
                _laser.enabled = false;
                if (_shown) { Place(); Menu.Dirty = true; _focus = -1; _kbMode = false; }
            }
            if (!_shown) return;

            if (Menu.JustOpened)
            {
                Menu.JustOpened = false;
                Place();
            }

            if (Menu.Dirty) Rebuild();

            bool left = !XRInput.IsLeft(Preferences.ToggleButton.Value); // pointer hand: opposite of toggle button
            Ray ray;
            bool mouse;
            bool havePointer = GetRay(left, out ray, out mouse);

            Hit hover = null;
            Vector2 local = Vector2.zero;
            bool onMenu = false;
            if (havePointer) onMenu = Intersect(ray, out local);

            if (onMenu)
            {
                hover = Pick(local);
                _kbMode = false;
            }

            SetHover(hover, left);

            // Cursor + laser
            _cursor.gameObject.SetActive(onMenu);
            if (onMenu) ((RectTransform)_cursor.transform).anchoredPosition = local;
            _laser.enabled = havePointer && !mouse;
            if (_laser.enabled)
            {
                Vector3 end = ray.origin + ray.direction * 1.2f;
                if (onMenu) end = _canvas.transform.TransformPoint(new Vector3(local.x, local.y, 0f));
                _laser.SetPosition(0, ray.origin);
                _laser.SetPosition(1, end);
            }

            // Clicking
            bool trigger = !mouse && XRInput.GetTrigger(left);
            bool click = (trigger && !_prevTrigger) || (mouse && MouseDown());
            _prevTrigger = trigger;
            if (click && hover != null)
            {
                int zone = 0;
                if (hover.Stepper)
                {
                    if (local.x < hover.Center.x - hover.Size.x / 2f + StepW) zone = -1;
                    else if (local.x > hover.Center.x + hover.Size.x / 2f - StepW) zone = 1;
                }
                Press(hover, zone, left);
            }

            ControllerNav(left);
            KeyboardNav(left);
            _rebuilt = false;
        }

        // ------------------------------------------------------------------------------------
        // Placement and pointing

        private void Place()
        {
            Transform head = Player.GetHead();
            float scale = BaseScale * Preferences.MenuSizePercent.Value / 100f;
            _canvas.transform.localScale = Vector3.one * scale;
            if (head == null)
            {
                _canvas.transform.position = new Vector3(0f, 1.5f, 1f);
                _canvas.transform.rotation = Quaternion.identity;
                return;
            }

            Vector3 flat = head.forward;
            flat.y = 0f;
            if (flat.sqrMagnitude < 0.0001f) flat = Vector3.forward;
            flat.Normalize();

            Vector3 pos = head.position + flat * (Preferences.MenuDistanceCm.Value / 100f);
            // A little below eye level so it doesn't block the view.
            pos.y = head.position.y - 0.05f;
            _canvas.transform.position = pos;
            // The canvas faces the viewer when its forward points away from them.
            _canvas.transform.rotation = Quaternion.LookRotation(flat, Vector3.up);
        }

        private bool GetRay(bool leftHand, out Ray ray, out bool mouse)
        {
            Vector3 p;
            Quaternion r;
            if (Player.TryGetHandPose(leftHand, out p, out r))
            {
                ray = new Ray(p, r * Vector3.forward);
                mouse = false;
                return true;
            }

            mouse = true;
            ray = new Ray();
            if (!Preferences.EnableKeyboard.Value) return false;
            Camera cam = Camera.main;
            if (cam == null) return false;
            try { ray = cam.ScreenPointToRay(Input.mousePosition); return true; }
            catch (Exception) { return false; }
        }

        private static bool MouseDown()
        {
            try { return Input.GetMouseButtonDown(0); } catch (Exception) { return false; }
        }

        /// <summary>Finds where the ray crosses the menu and converts it to canvas pixels.</summary>
        private bool Intersect(Ray ray, out Vector2 local)
        {
            local = Vector2.zero;
            Plane plane = new Plane(_canvas.transform.forward, _canvas.transform.position);
            float d;
            if (!plane.Raycast(ray, out d) || d > 3f) return false;

            Vector3 l = _canvas.transform.InverseTransformPoint(ray.GetPoint(d));
            if (Mathf.Abs(l.x) > W / 2f || Mathf.Abs(l.y) > H / 2f) return false;
            local = new Vector2(l.x, l.y);
            return true;
        }

        private Hit Pick(Vector2 p)
        {
            foreach (Hit h in _hits)
            {
                if (Mathf.Abs(p.x - h.Center.x) <= h.Size.x / 2f && Mathf.Abs(p.y - h.Center.y) <= h.Size.y / 2f)
                    return h;
            }
            return null;
        }

        private void SetHover(Hit hit, bool leftHand)
        {
            Hit shown = hit;
            if (shown == null && _kbMode && _focus >= 0)
            {
                int n = 0;
                foreach (Hit h in _hits)
                {
                    if (!h.IsRow) continue;
                    if (n == _focus) { shown = h; break; }
                    n++;
                }
            }

            if (shown != _hovered)
            {
                if (_hovered != null && _hovered.Bg != null) _hovered.Bg.color = _hovered.BaseColor;
                _hovered = shown;
                if (_hovered != null)
                {
                    if (_hovered.Bg != null) _hovered.Bg.color = UIKit.Scale(_hovered.BaseColor, 1.6f);
                    if (hit != null && !_rebuilt) XRInput.Haptic(leftHand, 0.1f, 0.02f);
                }
                if (_tooltipText != null) _tooltipText.text = _hovered != null && _hovered.Tooltip != null ? _hovered.Tooltip : "";
            }
        }

        private void Press(Hit hit, int zone, bool leftHand)
        {
            XRInput.Haptic(leftHand, 0.4f, 0.05f);
            try { hit.Click(zone); }
            catch (Exception e) { ModConsole.Error("Menu button threw: " + e); }
            Menu.MarkDirty();
        }

        // ------------------------------------------------------------------------------------
        // Extra input: thumbstick left/right flips pages, keyboard arrows etc.

        private void ControllerNav(bool pointerLeft)
        {
            Vector2 stick = XRInput.GetStick(pointerLeft);
            if (Mathf.Abs(stick.x) < 0.4f) { _stickReady = true; return; }
            if (!_stickReady || Mathf.Abs(stick.x) < 0.8f) return;
            _stickReady = false;
            if (stick.x > 0f) Menu.NextPage(); else Menu.PreviousPage();
        }

        private void KeyboardNav(bool leftHand)
        {
            if (!Preferences.EnableKeyboard.Value) return;
            try
            {
                int rows = 0;
                foreach (Hit h in _hits) if (h.IsRow) rows++;

                if (Input.GetKeyDown(KeyCode.DownArrow)) { _kbMode = true; _focus = rows == 0 ? -1 : (_focus + 1) % rows; }
                else if (Input.GetKeyDown(KeyCode.UpArrow)) { _kbMode = true; _focus = rows == 0 ? -1 : (_focus <= 0 ? rows - 1 : _focus - 1); }
                else if (Input.GetKeyDown(KeyCode.Backspace) || Input.GetKeyDown(KeyCode.Escape)) { Menu.GoBack(); }
                else if (Input.GetKeyDown(KeyCode.PageDown)) { Menu.NextPage(); }
                else if (Input.GetKeyDown(KeyCode.PageUp)) { Menu.PreviousPage(); }
                else
                {
                    int zone = 0;
                    bool act = Input.GetKeyDown(KeyCode.Return) || Input.GetKeyDown(KeyCode.KeypadEnter);
                    if (Input.GetKeyDown(KeyCode.LeftArrow)) { zone = -1; act = true; }
                    else if (Input.GetKeyDown(KeyCode.RightArrow)) { zone = 1; act = true; }
                    if (!act) return;

                    Hit focused = null;
                    int n = 0;
                    foreach (Hit h in _hits)
                    {
                        if (!h.IsRow) continue;
                        if (n == _focus) { focused = h; break; }
                        n++;
                    }

                    if (focused != null && (focused.Stepper || zone == 0)) { _kbMode = true; Press(focused, zone, leftHand); }
                    else if (zone == 1) Menu.NextPage();
                    else if (zone == -1) Menu.PreviousPage();
                }
                SetHover(null, leftHand);
            }
            catch (InvalidOperationException) { /* legacy input disabled */ }
        }

        // ------------------------------------------------------------------------------------
        // Drawing

        private void Rebuild()
        {
            Menu.Dirty = false;

            for (int i = _content.childCount - 1; i >= 0; i--)
            {
                GameObject child = _content.GetChild(i).gameObject;
                child.SetActive(false);
                Destroy(child);
            }
            _hits.Clear();
            _hovered = null;
            _tooltipText = null;
            _rebuilt = true;

            DialogData dialog = Menu.ActiveDialog;
            Page page = Menu.CurrentPage;
            Color accent = dialog != null ? Color.white : page.Color;

            // Frame and background
            UIKit.Box(_content, Vector2.zero, new Vector2(W + 10f, H + 10f), accent);
            UIKit.Box(_content, Vector2.zero, new Vector2(W, H), new Color(0.05f, 0.05f, 0.07f, 0.97f));

            // Header
            float headerY = H / 2f - HeaderH / 2f;
            UIKit.Box(_content, new Vector2(0f, headerY), new Vector2(W, HeaderH), UIKit.Scale(accent, 0.35f));
            string title = dialog != null ? dialog.Title : page.Name;
            UIKit.Label(_content, new Vector2(0f, headerY), new Vector2(W - 220f, HeaderH), title, 38, Color.white, TextAnchor.MiddleCenter);

            bool atRoot = dialog == null && page.Parent == null;
            AddButton(new Vector2(-W / 2f + Pad + 40f, headerY), new Vector2(80f, 60f), atRoot ? "" : "<", 40,
                      new Color(0.18f, 0.18f, 0.22f), null, false, z => { if (!atRoot) Menu.GoBack(); }, atRoot);
            AddButton(new Vector2(W / 2f - Pad - 40f, headerY), new Vector2(80f, 60f), "X", 34,
                      new Color(0.5f, 0.15f, 0.15f), "Close menu", false, z => Menu.Close(), false);

            // Tooltip line
            float footerY = -H / 2f + FooterH / 2f;
            _tooltipText = UIKit.Label(_content, new Vector2(0f, footerY - 30f), new Vector2(W - 2f * Pad, 40f), "", 24,
                                       new Color(0.75f, 0.75f, 0.8f), TextAnchor.MiddleCenter);

            if (dialog != null) BuildDialog(dialog);
            else BuildPage(page, footerY);
        }

        private float RowCenterY(int i)
        {
            float top = H / 2f - HeaderH - Gap;
            return top - RowH / 2f - i * (RowH + Gap);
        }

        private void BuildPage(Page page, float footerY)
        {
            List<Element> items = page.VisibleElements();
            if (items.Count == 0)
            {
                UIKit.Label(_content, new Vector2(0f, RowCenterY(1)), new Vector2(W - 80f, RowH), "Nothing here yet.", 30,
                            new Color(0.6f, 0.6f, 0.65f), TextAnchor.MiddleCenter);
            }

            float rowW = W - 2f * Pad;
            for (int i = 0; i < items.Count; i++)
            {
                Element e = items[i];
                Vector2 c = new Vector2(0f, RowCenterY(i));
                Vector2 size = new Vector2(rowW, RowH);

                Color bg = e.Interactable ? new Color(0.13f, 0.13f, 0.17f) : new Color(0.09f, 0.09f, 0.11f);
                Hit h = new Hit
                {
                    Center = c, Size = size, IsRow = e.Interactable, Stepper = e.Stepper,
                    Tooltip = e.Tooltip, BaseColor = bg
                };
                h.Bg = UIKit.Box(_content, c, size, bg);
                UIKit.Box(_content, new Vector2(c.x - rowW / 2f + 5f, c.y), new Vector2(10f, RowH), e.Color);

                float left = c.x - rowW / 2f;
                float textX0 = left + (e.Stepper ? StepW + 10f : 28f);
                float textX1 = c.x + rowW / 2f - (e.Stepper ? StepW + 10f : 20f);
                string value = e.ValueText;
                float valueW = string.IsNullOrEmpty(value) ? 0f : (e.Stepper || value.Length > 3 ? 170f : 90f);

                UIKit.Label(_content, new Vector2((textX0 + textX1 - valueW) / 2f, c.y),
                            new Vector2(textX1 - textX0 - valueW, RowH), e.Name, 30, e.Color, TextAnchor.MiddleLeft);
                if (valueW > 0f)
                    UIKit.Label(_content, new Vector2(textX1 - valueW / 2f, c.y), new Vector2(valueW, RowH), value, 30,
                                e.ValueColor, TextAnchor.MiddleRight);

                if (e.Stepper)
                {
                    UIKit.Box(_content, new Vector2(left + StepW / 2f + 4f, c.y), new Vector2(StepW - 8f, RowH - 16f), new Color(0.2f, 0.2f, 0.26f));
                    UIKit.Label(_content, new Vector2(left + StepW / 2f + 4f, c.y), new Vector2(StepW, RowH), "-", 44, Color.white, TextAnchor.MiddleCenter);
                    float rx = c.x + rowW / 2f - StepW / 2f - 4f;
                    UIKit.Box(_content, new Vector2(rx, c.y), new Vector2(StepW - 8f, RowH - 16f), new Color(0.2f, 0.2f, 0.26f));
                    UIKit.Label(_content, new Vector2(rx, c.y), new Vector2(StepW, RowH), "+", 44, Color.white, TextAnchor.MiddleCenter);
                }

                Element captured = e;
                h.Click = z => captured.Activate(z);
                if (e.Interactable) _hits.Add(h);
            }

            // Footer: previous / next screen of elements
            if (page.PageCount > 1)
            {
                float navY = footerY + 22f;
                bool hasPrev = page.PageIndex > 0;
                bool hasNext = page.PageIndex < page.PageCount - 1;
                AddButton(new Vector2(-W / 2f + Pad + 60f, navY), new Vector2(120f, 50f), hasPrev ? "<" : "", 34,
                          new Color(0.18f, 0.18f, 0.22f), "Previous page", false, z => Menu.PreviousPage(), !hasPrev);
                AddButton(new Vector2(W / 2f - Pad - 60f, navY), new Vector2(120f, 50f), hasNext ? ">" : "", 34,
                          new Color(0.18f, 0.18f, 0.22f), "Next page", false, z => Menu.NextPage(), !hasNext);
                UIKit.Label(_content, new Vector2(0f, navY), new Vector2(200f, 50f),
                            (page.PageIndex + 1) + " / " + page.PageCount, 28, Color.white, TextAnchor.MiddleCenter);
            }
        }

        private void BuildDialog(DialogData d)
        {
            float rowW = W - 2f * Pad;
            float bodyTop = RowCenterY(0) + RowH / 2f;
            float bodyH = 4f * RowH + 3f * Gap;
            Vector2 bodyC = new Vector2(0f, bodyTop - bodyH / 2f);
            UIKit.Box(_content, bodyC, new Vector2(rowW, bodyH), new Color(0.09f, 0.09f, 0.11f));

            float textW = rowW - 40f;
            float textX = 0f;
            if (d.Icon != null)
            {
                UIKit.Picture(_content, new Vector2(-rowW / 2f + 80f, bodyC.y + bodyH / 2f - 80f), new Vector2(110f, 110f), d.Icon);
                textW -= 140f;
                textX = 70f;
            }
            UIKit.Label(_content, new Vector2(textX, bodyC.y), new Vector2(textW, bodyH - 20f), d.Message, 30, Color.white, TextAnchor.MiddleCenter);

            DialogData captured = d;
            AddRow(4, d.PrimaryText, d.PrimaryColor, z => { Menu.ActiveDialog = null; captured.Primary.InvokeActionSafe(); });
            AddRow(5, d.SecondaryText, d.SecondaryColor, z => { Menu.ActiveDialog = null; captured.Secondary.InvokeActionSafe(); });
        }

        private void AddRow(int slot, string text, Color color, Action<int> click)
        {
            float rowW = W - 2f * Pad;
            Vector2 c = new Vector2(0f, RowCenterY(slot));
            Vector2 size = new Vector2(rowW, RowH);
            Color bg = new Color(0.13f, 0.13f, 0.17f);
            Hit h = new Hit { Center = c, Size = size, IsRow = true, BaseColor = bg, Click = click };
            h.Bg = UIKit.Box(_content, c, size, bg);
            UIKit.Box(_content, new Vector2(c.x - rowW / 2f + 5f, c.y), new Vector2(10f, RowH), color);
            UIKit.Label(_content, c, size, text, 32, color, TextAnchor.MiddleCenter);
            _hits.Add(h);
        }

        private void AddButton(Vector2 center, Vector2 size, string text, int fontSize, Color bg, string tooltip,
                               bool isRow, Action<int> click, bool disabled)
        {
            Image img = UIKit.Box(_content, center, size, disabled ? new Color(0f, 0f, 0f, 0f) : bg);
            UIKit.Label(_content, center, size, text, fontSize, Color.white, TextAnchor.MiddleCenter);
            if (disabled) return;
            _hits.Add(new Hit { Center = center, Size = size, Bg = img, BaseColor = bg, Tooltip = tooltip, IsRow = isRow, Click = click });
        }
    }
}
