using System;
using System.Reflection;
using HarmonyLib;
using UnityEngine;
using UnityEngine.SceneManagement;

namespace GorillaLib
{
    /// <summary>Events for common Gorilla Tag actions, plus a helper for creating Harmony hooks.</summary>
    public static class Hooking
    {
        /// <summary>Fired once the local player and head camera exist (and again after a full scene change).</summary>
        public static event Action OnPlayerReferencesFound;

        /// <summary>Fired when you join a Photon room. The argument is the room name.</summary>
        public static event Action<string> OnRoomJoined;

        /// <summary>Fired when you leave the current room.</summary>
        public static event Action OnRoomLeft;

        /// <summary>Fired when any scene finishes loading. The argument is the scene name.</summary>
        public static event Action<string> OnSceneLoaded;

        /// <summary>Fired when the GorillaLib menu opens.</summary>
        public static event Action OnMenuOpened;

        /// <summary>Fired when the GorillaLib menu closes.</summary>
        public static event Action OnMenuClosed;

        public static bool IsInRoom { get; private set; }
        public static string CurrentRoomName { get; private set; }

        private static bool _refsFired;
        private static float _roomTimer;
        private static Harmony _harmony;

        // Photon is read through reflection so GorillaLib has no hard dependency on its DLLs.
        private static PropertyInfo _inRoom;
        private static PropertyInfo _currentRoom;
        private static PropertyInfo _roomName;
        private static bool _photonSearched;

        internal static void Init()
        {
            SceneManager.sceneLoaded += OnUnitySceneLoaded;
        }

        private static void OnUnitySceneLoaded(Scene scene, LoadSceneMode mode)
        {
            if (mode == LoadSceneMode.Single)
            {
                Player.Invalidate();
                _refsFired = false;
            }
            OnSceneLoaded.RaiseSafe(scene.name);
        }

        internal static void Tick()
        {
            if (!_refsFired && Player.ReferencesFound)
            {
                _refsFired = true;
                OnPlayerReferencesFound.RaiseSafe();
            }

            _roomTimer -= Time.unscaledDeltaTime;
            if (_roomTimer <= 0f)
            {
                _roomTimer = 0.5f;
                PollRoom();
            }
        }

        internal static void RaiseMenuOpened() { OnMenuOpened.RaiseSafe(); }
        internal static void RaiseMenuClosed() { OnMenuClosed.RaiseSafe(); }

        private static void PollRoom()
        {
            try
            {
                if (!_photonSearched)
                {
                    _photonSearched = true;
                    Type pn = Player.FindType("Photon.Pun.PhotonNetwork");
                    if (pn != null)
                    {
                        _inRoom = pn.GetProperty("InRoom", BindingFlags.Public | BindingFlags.Static);
                        _currentRoom = pn.GetProperty("CurrentRoom", BindingFlags.Public | BindingFlags.Static);
                    }
                }
                if (_inRoom == null) return;

                bool inRoom = (bool)_inRoom.GetValue(null, null);
                if (inRoom == IsInRoom) return;

                IsInRoom = inRoom;
                if (inRoom)
                {
                    string name = "";
                    object room = _currentRoom != null ? _currentRoom.GetValue(null, null) : null;
                    if (room != null)
                    {
                        if (_roomName == null) _roomName = room.GetType().GetProperty("Name");
                        if (_roomName != null) name = (string)_roomName.GetValue(room, null);
                    }
                    CurrentRoomName = name;
                    OnRoomJoined.RaiseSafe(name);
                }
                else
                {
                    CurrentRoomName = null;
                    OnRoomLeft.RaiseSafe();
                }
            }
            catch (Exception e)
            {
                ModConsole.Debug("Room polling failed: " + e.Message);
                _inRoom = null; // stop polling if Photon changed shape
            }
        }

        /// <summary>
        /// Patches <paramref name="target"/> with a Harmony prefix or postfix.
        /// The hook method must be static.
        /// </summary>
        public static void CreateHook(MethodInfo target, MethodInfo hook, bool isPrefix = true)
        {
            if (target == null || hook == null)
            {
                ModConsole.Error("CreateHook: target or hook was null.");
                return;
            }

            try
            {
                if (_harmony == null) _harmony = new Harmony("com.gorillalib.hooks");
                HarmonyMethod hm = new HarmonyMethod(hook);
                if (isPrefix) _harmony.Patch(target, hm, null);
                else _harmony.Patch(target, null, hm);
            }
            catch (Exception e)
            {
                ModConsole.Error("CreateHook failed for " + target.Name + ": " + e);
            }
        }
    }
}
